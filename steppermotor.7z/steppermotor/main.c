/*
 * main.c
 *
 *  Created on: Apr 21, 2019
 *      Author: students
 */
#include <avr/io.h>
#include <util/delay.h>

int main(){

	//to count steps
	uint32_t steps = 0;

	DDRD = 0b11110000;
	PORTD = 0x00;

	while(1){
		// PD7 > A  > IN1
		// PD6 > B  > IN2
		// PD5 > A' > IN3
		// PD4 > B' > IN4
/*
       //Wave drive

		PORTD = 0b10000000;	// STEP 1
		_delay_ms(11);

			PORTD = 0b01000000;	// STEP 2
				_delay_ms(11);

				PORTD = 0b00100000;	// STEP 3
						_delay_ms(11);

						PORTD = 0b00010000;	// STEP 4
								_delay_ms(11);
*/
/*
		//Full Step mode

		PORTD = 0b11000000;	// STEP 1 > AB
		_delay_ms(11);

			PORTD = 0b01100000;	// STEP 2 > BA'
				_delay_ms(11);

				PORTD = 0b00110000;	// STEP 3 > A'B'
						_delay_ms(11);

						PORTD = 0b10010000;	// STEP 4 > B'A
								_delay_ms(11);

			steps+=4;

*/


		PORTD = 0b10000000;	// STEP 1
		_delay_ms(11);

		PORTD = 0b11000000;	// STEP 1 > AB
		_delay_ms(11);


			PORTD = 0b01000000;	// STEP 2
				_delay_ms(11);

			PORTD = 0b01100000;	// STEP 2 > BA'
				_delay_ms(11);


					PORTD = 0b00100000;	// STEP 3
						_delay_ms(11);

					PORTD = 0b00110000;	// STEP 3 > A'B'
						_delay_ms(11);


						PORTD = 0b00010000;	// STEP 4
								_delay_ms(11);
						PORTD = 0b10010000;	// STEP 4 > B'A
								_delay_ms(11);



			steps+=8;

	}
}
