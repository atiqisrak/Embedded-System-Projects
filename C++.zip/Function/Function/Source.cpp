#include<iostream>
using namespace std;

int add(double a, double b)
{
	return(a + b);
}
int main()
{
	double a, b;
	int z=true;
	while (z)
	{
		cout << "enter 2 numbers: " << endl;
		cin >> a >> b;
		auto x = add(a, b);
		cout << "sum :" << x << endl;
	}
		return 0;
}
