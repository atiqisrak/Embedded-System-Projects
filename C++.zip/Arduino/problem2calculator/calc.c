/*
 * calc.c
 *
 *  Created on: Apr 10, 2019
 *      Author: niloy
 */

#include <avr/io.h>

void operations(A,B,op){
	int result=0;
	switch(op){
	    case "+" : result = A+B;
	    break;
	    case "-" : result = A-B;
	    break;
	    case ">" : if(A>B) result = "A>B";
	    break;
	    case "<" : if(B>A)result = "A<B";
	    break;
	    case ">>" : result = A>>B;
	    break;
	    case "<<" : result = A<<B;
	    break;
	    default: result = "No Operation";
}

	return result;
}

int main(){
	int A,B,op;
	operations();
	}
