#include <avr/io.h>
#include <avr/delay.h>

#define F_CPU 16000000UL

const uint8_t segment_look_up[] ={
				0b01111110,//0
				0b00110000,//1
				0b01101101,//2
				0b01111001,//3
				0b00110011,//4
				0b01011011,//5
				0b00011111,//6
				0b01110000,//7
				0b01111111,//8
				0b01110011,//9
				0b01110111,//A
				0b00011111,//b
				0b01001110,//C
				0b00111101,//d
				0b01001111,//E
				0b01000111 //F
};

int main()
{
	DDRC = 0xFF;
	PORTC = 0x00;
	DDRD = 0xFF;
	PORTD = 0x00;
	DDRB &= ~(1 << PB2); // PORTB2 as increase input
	DDRB &= ~(1 << PB5); // PORTB5 as decrease input
	uint8_t i;
	while(1)
	{
		{

			PORTC= segment_look_up[i];
			PORTD= segment_look_up[i]; //switching patterns

			//increase
			if (bit_is_clear(PINB, PINB2))
			{
				_delay_ms(100);
				while(bit_is_clear(PINB, PINB2))
				{
					_delay_ms(100);
					PORTC = 0x00;
					PORTD = 0x00;
					continue;
				}
				i = (i + 1) % 16; //pattern number increment
			}

			//decrease
			if (bit_is_clear(PINB, PINB5))
			{
				_delay_ms(100);
				while(bit_is_clear(PINB, PINB5))
				{
					_delay_ms(100);
					PORTC = 0x00;
					PORTD = 0x00;
					continue;
				}
				i = 16- ((i + 1) % 16); //pattern number decrement
			}
		}
	}
}
