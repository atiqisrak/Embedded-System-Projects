/*
 * ArduinoTest1.c
 *
 * Created: 2/13/2019 12:13:56 AM
 * Author : niloy
 */ 
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
    /* Replace with your application code */
	DDRB = 0b00100000;
	PORTB = 0x00;
	
    while (1) 
    {
		PORTB = 0b00100000;
		_delay_ms(500);
		
		PORTB = 0b00000000;
		_delay_ms(500);
    }
}