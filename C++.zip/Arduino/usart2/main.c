/*
 * main.c
 *
 *  Created on: Apr 10, 2019
 *      Author: niloy
 */

#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>

#define F_CPU 16000000UL
#define FOSC 16000000 //hz

///USART
#define BAUD 9600 /**< Baud Rate in bps. refer page 179 of 328p datasheet. */
#define MYUBRR FOSC/16/BAUD-1 /**< UBRR = (F_CPU/(16*Baud))-1 for asynch USART page 179 328p datasheet. Baud rate 9600bps, assuming	16MHz clock UBRR0 becomes 0x0067*/
////////////////USART Start///////////////////////////////////////

const uint8_t segment_look_up[] ={
				0b01111110,//0
				0b00110000,//1
				0b01101101,//2
				0b01111001,//3
				0b00110011,//4
				0b01011011,//5
				0b00011111,//6
				0b01110000,//7
				0b01111111,//8
				0b01110011,//9
				0b01110111,//A
				0b00011111,//b
				0b01001110,//C
				0b00111101,//d
				0b01001111,//E
				0b01000111 //F
};
int result;

void USART_init(unsigned int ubrr) {

	UCSR0C = (0 << USBS0) | (3 << UCSZ00); /// Step 1. Set UCSR0C in Asynchronous mode, no parity, 1 stop bit, 8 data bits
	UCSR0A = 0b00000000; /// Step 2. Set UCSR0A in Normal speed, disable multi-proc

	UBRR0H = (unsigned char) (ubrr >> 8); /// Step 3. Load ubrr into UBRR0H and UBRR0L
	UBRR0L = (unsigned char) ubrr;

	UCSR0B = 0b00011000; /// Step 4. Enable Tx Rx and disable interrupt in UCSR0B
}
int USART_send(char c, FILE *stream) {

	while (!( UCSR0A & (1 << UDRE0))) /// Step 1.  Wait until UDRE0 flag is high. Busy Waitinig
	{
		;
	}

	UDR0 = c; /// Step 2. Write char to UDR0 for transmission
}
int USART_receive( FILE *stream) {

	while (!(UCSR0A & (1 << RXC0)))
		/// Step 1. Wait for Receive Complete Flag is high. Busy waiting
		;

	return (UDR0); /// Step 2. Get and return received data from buffer
}

void init_ADC(){
	ADMUX = 0b01000000;
	DIDR0 = 0b00000001;
	ADCSRA = 0b10000111;
}

int main(){
	USART_init(MYUBRR);
	stdout = fdevopen(USART_send, NULL);
		stdin = fdevopen(NULL, USART_receive);

		uint8_t num = 0;
		DDRC = 0xFF;
		PORTC = 0x00;
		DDRD = 0xFF;
		PORTD = 0x00;
		DDRB &= ~(1 << PB2); // PORTB2 as increase input
		DDRB &= ~(1 << PB5); // PORTB5 as decrease input
		uint8_t i;
		while(1)
		{
			{

				PORTC= segment_look_up[i];
				PORTD= segment_look_up[i]; //switching patterns

				//increase
				if (bit_is_clear(PINB, PINB2))
				{
					_delay_ms(100);
					while(bit_is_clear(PINB, PINB2))
					{
						_delay_ms(100);
						PORTC = 0x00;
						PORTD = 0x00;
						continue;
					}
					i = (i + 1) % 16; //pattern number increment
				}

				//decrease
				if (bit_is_clear(PINB, PINB5))
				{
					_delay_ms(100);
					while(bit_is_clear(PINB, PINB5))
					{
						_delay_ms(100);
						PORTC = 0x00;
						PORTD = 0x00;
						continue;
					}
					i = 16- ((i + 1) % 16); //pattern number decrement
				}
			}
		}

		while(1){

			scanf("%hhu", &num);
			printf("7 Segment value = %hhu\n", &num);

		}
}
