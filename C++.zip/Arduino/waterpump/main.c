/*
 * main.c
 *
 *  Created on: Apr 10, 2019
 *      Author: niloy
 */

#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>

void level_high(){

}
void level_low(){

}


int main(){

	DDRC = 0xFF;
		PORTC = 0x00;
	DDRD = 0xFF;
		PORTD = 0x00;

	while(1){
		if(level_high()){
			PORTC |= ~(1<<levIn);
		}
		if(level_low()){
					PORTC |= (1<<levIn);
				}
		if(bit_is_set(PIND,levIn)){
							start();
						}
		if(bit_is_set(PIND,levIn)){
									stop();
								}

	}
}
